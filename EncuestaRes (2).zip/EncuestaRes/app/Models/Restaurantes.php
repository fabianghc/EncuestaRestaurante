<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Models\Restaurante;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Restaurantes extends Model
{
    
    use HasFactory;
    protected $table = 'restaurante';
    protected $primaryKey = 'idRestaurante'; // Cambia al nombre correcto de la clave primaria
    protected $fillable = ['Ruc', 'razon_social', 'nombre', 'codigo_validacion', 'estado']; 
    
    
}

