<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;

class Authenticate extends Middleware
{
    /**
     * Obtén la URL a la que redirigir cuando el usuario no esté autenticado.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return string|null
     */
    protected function redirectTo($request)
    {
        if (!$request->expectsJson()) {
            #dd('Redirigiendo al login de administrador...');
            return route('admin.authenticate'); // Redirige al login de administrador en caso de no estar autenticado
        }
    }
}
