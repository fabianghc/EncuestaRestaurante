<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Models\Encuestas;
use App\Models\Restaurantes;

class ExportController extends Controller
{
    public function exportarSQL()
    {
        // Ejecutar la consulta SQL directamente
        $datos = DB::select("
            SELECT r.Ruc, r.razon_social, r.nombre AS nombre_restaurante,
                   e.nombre AS nombre_encuestado, e.numCelular, e.informacion
            FROM restaurante r
            INNER JOIN encuesta e ON r.idRestaurante = e.idRestaurante
        ");

        // Crear respuesta para descargar archivo
        $response = new StreamedResponse(function () use ($datos) {
            $handle = fopen('php://output', 'w');

            // Encabezados del archivo CSV
            fputcsv($handle, ['RUC', 'Razón Social', 'Nombre Restaurante', 'Nombre Encuestado', 'Número Celular', 'Información']);

            // Insertar filas de la consulta SQL
           /* foreach ($datos as $fila) {
                fputcsv($handle, [
                    $fila->ruc,
                    $fila->razon_social,
                    $fila->nombre_restaurante,
                    $fila->nombre_encuestado,
                    $fila->numcelular,
                    $fila->informacion
                ]);
            }*/
            fputcsv($handle, ['123456789', 'Empresa S.A.', 'Restaurante Ejemplo', 'Juan Pérez', '987654321', 'Excelente servicio']);

            fclose($handle);
        });

        // Configurar la respuesta como descarga
        $response->headers->set('Content-Type', 'text/csv');
        $response->headers->set('Content-Disposition', 'attachment; filename="exportacion_restaurante.csv"');
        $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
$response->headers->set('Pragma', 'no-cache');
$response->headers->set('Expires', '0');

        return $response;
    }


public function exportarExcel()
{
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Encabezados
    $sheet->setCellValue('A1', 'RUC');
    $sheet->setCellValue('B1', 'Razón Social');
    $sheet->setCellValue('C1', 'Nombre Restaurante');
    $sheet->setCellValue('D1', 'Nombre Encuestado');
    $sheet->setCellValue('E1', 'Número Celular');
    $sheet->setCellValue('F1', 'Información');

    // Datos
    $datos = DB::table('restaurante')
        ->join('encuesta', 'restaurante.id', '=', 'encuesta.idRestaurante')
        ->select('restaurante.Ruc', 'restaurante.razon_social', 'restaurante.nombre as nombre_restaurante',
                 'encuesta.nombre as nombre_encuestado', 'encuesta.numcelular', 'encuesta.informacion')
        ->get();

    $fila = 2;
    foreach ($datos as $dato) {
        $sheet->setCellValue('A' . $fila, $dato->ruc);
        $sheet->setCellValue('B' . $fila, $dato->razon_social);
        $sheet->setCellValue('C' . $fila, $dato->nombre_restaurante);
        $sheet->setCellValue('D' . $fila, $dato->nombre_encuestado);
        $sheet->setCellValue('E' . $fila, $dato->numcelular);
        $sheet->setCellValue('F' . $fila, $dato->informacion);
        $fila++;
    }

    // Guardar como archivo Excel
    $writer = new Xlsx($spreadsheet);

    // Configurar descarga
    $nombreArchivo = "exportacion_restaurante.xlsx";
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'. $nombreArchivo .'"');
    $response->headers->set('Cache-Control', 'must-revalidate, post-check=0, pre-check=0');
    $response->headers->set('Pragma', 'public');
    $response->headers->set('Expires', '0');
    $writer->save('php://output');
    exit;
}
public function export()
{
    // Crear un nuevo archivo de Excel
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Definir encabezados
    $headers = [
        'A1' => 'CÓDIGO VALIDACIÓN',
        'B1' => 'Restaurante',
        'C1' => 'RUC',
        'D1' => 'Razón Social',
        'E1' => 'Nombre del Respondiente',
        'F1' => 'Celular',
        'G1' => 'Información Extra'
    ];

    // Aplicar encabezados con formato
    foreach ($headers as $cell => $value) {
        $sheet->setCellValue($cell, $value);
    }

    // Aplicar estilo a los encabezados (negrita y centrado)
    $styleArray = [
        'font' => [
            'bold' => true
        ],
        'alignment' => [
            'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
        ]
    ];
    $sheet->getStyle('A1:G1')->applyFromArray($styleArray);

    // Obtener datos desde la base de datos
    $encuestas = Encuestas::join('restaurante', 'encuesta.idRestaurante', '=', 'restaurante.idRestaurante')
        ->select(
            'restaurante.codigo_validacion as codigoValidacion',
            'restaurante.nombre as Restaurante',
            'restaurante.Ruc as RUC',
            'restaurante.razon_social as RazonSocial',
            'encuesta.nombre as Respondiente',
            'encuesta.numCelular as Celular',
            'encuesta.informacion as InformacionExtra'
        )
        ->get();

    // Insertar datos en las filas
    $row = 2; // Comenzamos en la segunda fila (la primera tiene los encabezados)
    foreach ($encuestas as $encuesta) {
        $sheet->setCellValue('A' . $row, $encuesta->codigoValidacion);
        $sheet->setCellValue('B' . $row, $encuesta->Restaurante);
        $sheet->setCellValue('C' . $row, $encuesta->RUC);
        $sheet->setCellValue('D' . $row, $encuesta->RazonSocial);
        $sheet->setCellValue('E' . $row, $encuesta->Respondiente);
        $sheet->setCellValue('F' . $row, $encuesta->Celular);
        $sheet->setCellValue('G' . $row, $encuesta->InformacionExtra);

        $row++;
    }

    // Ajustar automáticamente el ancho de las columnas
    foreach (range('A', 'G') as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }

    // Guardar archivo en memoria y devolver como descarga
    $writer = new Xlsx($spreadsheet);
    $response = new StreamedResponse(function () use ($writer) {
        $writer->save('php://output');
    });

    $response->headers->set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    $response->headers->set('Content-Disposition', 'attachment;filename="encuestas.xlsx"');
    $response->headers->set('Cache-Control', 'max-age=0');

    return $response;
}


}
