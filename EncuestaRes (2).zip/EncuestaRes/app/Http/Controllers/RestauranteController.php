<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Restaurantes;
use App\Models\Encuestas;
use Maatwebsite\Excel\Facades\Excel;
#use Maatwebsite\Excel\Excel;
use App\Exports\EncuestasExport;
use App\Http\Controllers\ExportController;

class RestauranteController extends Controller
{
    //
    //
    public function index()
{
    return view('restaurantes.cargar');
}
public function import(Request $request)
{
    // Validar el archivo cargado
    $request->validate([
        'archivo' => 'required|mimes:xlsx,xls',
    ]);

    // Eliminar todos los registros actuales
    Restaurantes::truncate();

    // Leer el archivo Excel
    Excel::import(new \App\Imports\RestaurantesImport, $request->file('archivo'));

    return redirect()->back()->with('success', 'Los restaurantes fueron cargados exitosamente.');
}
public function showValidationForm()
    {
        return view('restaurante.validacion');
    }

    public function validateCode(Request $request)
{
    $request->validate(['codigo' => 'required|string']);

    $restaurant = Restaurantes::where('codigo_validacion', $request->codigo)->first();

    if (!$restaurant) {
        return back()->withErrors(['codigo' => 'Código no válido']);
    }
    // Verificar si el restaurante ya ha respondido la encuesta
    $encuestaRespondida = Encuestas::where('idRestaurante', $restaurant->idRestaurante)->exists();

    if ($encuestaRespondida) {
        return view('restaurante.encuesta_contestada');
    }
    // Guarda el restaurante en la sesión
    session(['restaurant' => $restaurant]);

    // Redirige a la vista con el modal de bienvenida
    return view('restaurante.confirmacion', ['restaurant' => $restaurant]);
}

public function showSurveyForm(Request $request)
{
    // Obtén el restaurante de la sesión
    $restaurant = session('restaurant');

    if (!$restaurant) {
        // Si no hay restaurante en la sesión, redirige al formulario de validación
        return redirect()->route('validacion.form');
    }

    // Muestra el formulario de encuesta
    return view('restaurante.encuesta', ['restaurant' => $restaurant]);
}
    public function submitSurvey(Request $request)
    {
        // Obtén el restaurante de la sesión
    $restaurant = session('restaurant');

        $request->validate([
            'nombre' => 'required|string|max:255',
            'numCelular' => 'required|string|max:20',
            'informacion' => 'required|string',
            'archivo' => 'nullable|mimes:jpg,jpeg,png,pdf|max:2048', // Opcional
            'idRestaurante' => 'required|exists:restaurante,idRestaurante'
        ]);
        // Manejo del archivo (si se adjunta)
        $archivoRuta = null;
        if ($request->hasFile('archivo')) {
            $archivoRuta = $request->file('archivo')->store('uploads', 'public');
        }

        // Aquí guardarías los datos en la base de datos o realizas otra lógica

        // Registro de la encuesta en la base de datos
        Encuestas::create([
            'nombre' => $request->input('nombre'),
            'numCelular' => $request->input('numCelular'),
            'informacion' => $request->input('informacion'),
            'archivo' => $archivoRuta, // Puede ser null si no se adjunta
            'idRestaurante' => $request->input('idRestaurante'),
        ]);
           // Actualizar el estado del restaurante a 'S'
    $restaurante = Restaurantes::find($request->input('idRestaurante'));
    $restaurante->estado = 'S';
    $restaurante->save();
        // Limpia la sesión después de registrar la encuesta
    session()->forget('restaurant');

        // Redireccionar con mensaje de éxito
        return redirect()->route('agradecimiento');
    }
    public function verEncuesta($id)
    {
        $restaurante = Restaurantes::findOrFail($id);
        $encuesta = Encuestas::where('idRestaurante', $id)->first();

        if (!$encuesta) {
            abort(404, 'Encuesta no encontrada para este restaurante.');
        }

        return view('admin.verencuesta', compact('restaurante', 'encuesta'));
    }
    protected $excel;

    public function __construct(Excel $excel)
    {
        $this->excel = $excel;
    }
    public function exportarEncuestas()
    {
        return $this->excel->download(new EncuestasExport(), 'Encuestas.xlsx');
    }
    
}