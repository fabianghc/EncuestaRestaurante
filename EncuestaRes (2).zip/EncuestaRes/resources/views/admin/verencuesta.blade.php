@php
    use Illuminate\Support\Facades\Storage;
@endphp
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Administrador</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background-color: #f4f6f9;
    }
    .card {
      border: none;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .card-header {
      font-size: 1.25rem;
      font-weight: bold;
      color: #fff;
      padding: 1rem;
    }
    /* Color para la cabecera de "Datos del Restaurante" */
    .card-header.restaurant {
      background: linear-gradient(90deg, #007bff, #00c6ff);
    }
    /* Color para la cabecera de "Respuesta de la Encuesta" */
    .card-header.encuesta {
      background: linear-gradient(90deg, #28a745, #85e085);
    }
    .card-body {
      background-color: #fff;
      padding: 1.5rem;
    }
    h1 {
      color: #333;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <h1 class="mb-4 text-center">Respuesta de Encuesta</h1>

    <div class="card mb-4">
      <div class="card-header restaurant">Datos del Restaurante</div>
      <div class="card-body">
        <p><strong>Nombre:</strong> {{ $restaurante->nombre }}</p>
        <p><strong>RUC:</strong> {{ $restaurante->Ruc }}</p>
        <p><strong>Razón Social:</strong> {{ $restaurante->razon_social }}</p>
      </div>
    </div>

    <div class="card">
      <div class="card-header encuesta">Respuesta de la Encuesta</div>
      <div class="card-body">
        <p><strong>Nombre del Respondiente:</strong> {{ $encuesta->nombre }}</p>
        <p><strong>Número de Celular:</strong> {{ $encuesta->numCelular }}</p>
        <p><strong>Información Extra:</strong> {{ $encuesta->informacion }}</p>

        @if ($encuesta->archivo)
          <p><strong>Archivo Adjunto:</strong>
            <a href="{{ asset('storage/' . $encuesta->archivo) }}" class="btn btn-success btn-sm" download>
              Descargar Archivo
            </a>
          </p>
        @else
          <p><strong>Archivo Adjunto:</strong> No se adjuntó ningún archivo.</p>
        @endif
      </div>
    </div>
  </div>
</body>
</html>
