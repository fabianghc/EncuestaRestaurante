<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <title>Dashboard Administrador</title>
  <style>
    /* Estilos adicionales para un toque más colorido */
    .card-header {
      background: linear-gradient(90deg, #007bff, #00c6ff);
      color: #fff;
    }
    .table thead {
      background-color: #343a40;
      color: #fff;
    }
    .btn-success {
      background-color: #28a745;
      border-color: #28a745;
    }
    /* Colores para las columnas de la tabla */
    .table-striped tbody tr td:nth-child(1) {
      background-color: #E3F2FD; /* Light Blue */
    }
    .table-striped tbody tr td:nth-child(2) {
      background-color: #FCE4EC; /* Light Pink */
    }
    .table-striped tbody tr td:nth-child(3) {
      background-color: #E8F5E9; /* Light Green */
    }
    .table-striped tbody tr td:nth-child(4) {
      background-color: #FFFDE7; /* Light Yellow */
    }
    .table-striped tbody tr td:nth-child(5) {
      background-color: #E1F5FE; /* Light Cyan */
    }
    
  </style>
</head>
<body>
  <div class="container mt-5">
    <div class="card shadow">
      <div class="card-header">
        <h1 class="mb-0">Listado de Respuestas de Restaurantes</h1>
      </div>
      <div class="card-body">
        @if($restaurantes->isEmpty())
          <div class="alert alert-info">No hay restaurantes registrados aún.</div>
        @else
          <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
              <thead>
                <tr>
                  <th>#</th>
                  <th>RUC</th>
                  <th>Razón Social</th>
                  <th>Nombre</th>
                  <th>Encuesta Respondida</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                @foreach($restaurantes as $restaurante)
                  <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $restaurante->Ruc }}</td>
                    <td>{{ $restaurante->razon_social }}</td>
                    <td>{{ $restaurante->nombre }}</td>
                    <td>{{ $restaurante->estado === 'S' ? 'Sí' : 'No' }}</td>
                    <td>
                      @if($restaurante->estado === 'S')
                        <a href="{{ route('encuestas.ver', $restaurante->idRestaurante) }}" class="btn btn-primary btn-sm">Ver Encuesta</a>
                      @else
                        <span class="text-muted">Sin acciones</span>
                      @endif
                    </td>
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
          <a href="{{ route('exportar.sql') }}" class="btn btn-success mb-3">
            Descargar Respuestas en Excel
          </a>
        @endif
      </div>
    </div>
  </div>
</body>
</html>

