<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Encuesta</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background: linear-gradient(90deg, #f8f9fa, #e9ecef);
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }
    .container {
      max-width: 800px;
    }
    h2 {
      color: #343a40;
      text-align: center;
      margin-bottom: 30px;
      text-decoration: underline;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    p, ul {
      font-size: 1.1rem;
      color: #495057;
    }
    ul li {
      margin-bottom: 10px;
    }
    .card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      margin-bottom: 30px;
    }
    .card-header {
      background: linear-gradient(90deg, #007bff, #00c6ff);
      color: #fff;
      font-weight: bold;
      font-size: 1.25rem;
      border-bottom: none;
      padding: 1rem 1.5rem;
    }
    .card-body {
      padding: 1.5rem;
      background-color: #fff;
    }
    .btn-primary {
      background: linear-gradient(90deg, #007bff, #00c6ff);
      border: none;
    }
    .btn-primary:disabled {
      opacity: 0.6;
    }
    a.text-decoration-underline {
      color: #007bff;
      font-weight: bold;
    }
  </style>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const nombreInput = document.getElementById('nombre');
      const celularInput = document.getElementById('numCelular');
      const informacionInput = document.getElementById('informacion');
      const submitButton = document.querySelector('button[type="submit"]');

      function toggleSubmitButton() {
          if (nombreInput.value.trim() !== '' && celularInput.value.trim() !== '' && informacionInput.value.trim() !== '') {
              submitButton.disabled = false;
          } else {
              submitButton.disabled = true;
          }
      }

      nombreInput.addEventListener('input', toggleSubmitButton);
      celularInput.addEventListener('input', toggleSubmitButton);
      informacionInput.addEventListener('input', toggleSubmitButton);

      // Estado inicial
      toggleSubmitButton();
    });
  </script>
</head>
<body>
  <div class="container mt-5">
    <h2>Concurso de Restaurante Inteligente</h2>
    <div class="card ">
      
      <div class="card-body p-4 mb-4">
        <p> <strong>¿Sabías que el módulo Restaurante Inteligente de Gesrest te brinda acceso a <a href="#" data-bs-toggle="modal" data-bs-target="#dashboardModal" class="text-decoration-underline">DASHBOARDS</a> interactivos con <a href="#" data-bs-toggle="modal" data-bs-target="#indicadoresModal" class="text-decoration-underline">INDICADORES DE GESTIÓN</a> claves para tomar mejores decisiones en tu negocio?</strong></p>
        <ul>
          <li>Descubre patrones en tus ventas 📈</li>
          <li>Identifica tendencia en demanda de productos 🍔✨</li>
          <li>Optimiza horarios de atención y recursos ⏳👥</li>
          <li>Toma decisiones basadas en datos, no en suposiciones 💡</li>
        </ul>
        <p>Queremos que estos reportes sean aún más útiles para ti. Así que, cuéntanos qué información te gustaría saber:</p>
      </div>
    </div>

    <div class="card">
    <div class="card-header">Participa en la Encuesta</div>
      <div class="card-body">
        <form action="{{ route('encuesta.submit') }}" method="POST" enctype="multipart/form-data">
          @csrf
          <input type="hidden" name="idRestaurante" value="{{ $restaurant->idRestaurante }}">
          <div class="mb-3">
            <label for="nombre" class="form-label">Tu nombre*</label>
            <input type="text" class="form-control" id="nombre" name="nombre" required>
          </div>
          <div class="mb-3">
            <label for="celular" class="form-label">Tu número de celular*</label>
            <input type="text" class="form-control" id="numCelular" name="numCelular" required>
          </div>
          <div class="mb-3">
            <label for="informacion" class="form-label">¿Qué información te gustaría conocer sobre tu negocio?*</label>
            <textarea class="form-control" id="informacion" name="informacion" rows="3" required></textarea>
          </div>
          <div class="mb-3">
            <label for="archivo" class="form-label">¿Tienes algún formato o gráfico que te gustaría que implementemos? (opcional)</label>
            <input type="file" class="form-control" id="archivo" name="archivo">
          </div>
          <button type="submit" class="btn btn-primary" disabled>Enviar datos</button>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal for Dashboards -->
  <div class="modal fade" id="dashboardModal" tabindex="-1" aria-labelledby="dashboardModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="dashboardModalLabel">¿Qué es un Dashboard?</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Un Dashboard es una herramienta visual que permite monitorear y analizar datos clave para tomar decisiones estratégicas en tu negocio.</p>
          <img src="{{ asset('images/restaurantes/dashboard_example.png') }}" alt="Ejemplo de Dashboard" class="img-fluid">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal for Indicadores de Gestión -->
  <div class="modal fade" id="indicadoresModal" tabindex="-1" aria-labelledby="indicadoresModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="indicadoresModalLabel">¿Qué son los Indicadores de Gestión?</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Los Indicadores de Gestión son métricas que miden el desempeño de diferentes áreas de tu negocio para mejorar su eficiencia.</p>
          <img src="{{ asset('images/restaurantes/indicadores_example.png') }}" alt="Ejemplo de Indicadores de Gestión" class="img-fluid">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
