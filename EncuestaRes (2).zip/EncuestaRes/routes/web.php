<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RestauranteController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ImportExcelController;

Route::get('/', function () {
    return view('restaurante.validacion');
});



Route::get('/codigo', [RestauranteController::class, 'showValidationForm'])->name('validacion.form');
Route::post('/validacion', [RestauranteController::class, 'validateCode'])->name('validacion.validate');
Route::get('/encuesta', [RestauranteController::class, 'showSurveyForm'])->name('encuesta.form');
Route::post('/registrar', [RestauranteController::class, 'submitSurvey'])->name('encuesta.submit');



Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'authenticate'])->name('admin.authenticate');
Route::post('/logout', [AdminController::class, 'logout'])->name('admin.logout');
#Route::get('/admin/dashboard', [AdminController::class, 'dashboard'])->middleware('auth:admin')->name('admin.dashboard');

Route::get('/import', [ImportExcelController::class, 'showImportForm'])->name('import.form');
Route::post('/import', [ImportExcelController::class, 'import'])->name('import.excel');

Route::get('/agradecimiento', function () {
    return view('restaurante.agradecimiento');
})->name('agradecimiento');
Route::get('/exportar-sql', [ExportController::class, 'export'])->name('exportar.sql');

Route::middleware(['web'])->group(function () {
#    Route::get('/loginAdmin', [AdminController::class, 'showLoginForm'])->name('admin.login');
#    Route::post('/loginAdmin', [AdminController::class, 'authenticate'])->name('admin.authenticate');
#
    Route::get('/admin/dashboard', [AdminController::class, 'dashboard']) ->name('admin.dashboard');
    Route::get('/admin/encuestas/exportar', [RestauranteController::class, 'exportarEncuestas'])->name('encuestas.exportar');
    Route::get('/admin/encuestas/{id}', [RestauranteController::class, 'verEncuesta'])->name('encuestas.ver');

});
