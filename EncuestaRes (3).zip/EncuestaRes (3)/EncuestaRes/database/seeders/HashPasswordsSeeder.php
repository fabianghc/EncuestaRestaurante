<?php

namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB; // Importa DB
use Illuminate\Support\Facades\Hash; 

use Illuminate\Database\Console\Seeds\WithoutModelEvents;


class HashPasswordsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $admins = DB::table('administrador')->get();

        foreach ($admins as $admin) {   
            DB::table('administrador')
                ->where('idAdministrador', $admin->idAdministrador)
                ->update(['contraseña' => Hash::make($admin->contraseña)]);
        }
    }
}
