<?php
namespace App\Exports;

use App\Models\Encuestas;
use Maatwebsite\Excel\Excel;
#use Maatwebsite\Excel\Facades\Excel;
#use \Excel;
use Maatwebsite\Excel\Writers\LaravelExcelWriter;

class EncuestasExport
{
    /**
     * Exporta los datos a Excel.
     */
    public function export()
    {
        $data = Encuestas::join('restaurante', 'encuesta.idRestaurante', '=', 'restaurante.idRestaurante')
            ->select(
                'restaurante.nombre as Restaurante',
                'restaurante.Ruc as RUC',
                'restaurante.razon_social as Razón_Social',
                'encuesta.nombre as Respondiente',
                'encuesta.numCelular as Celular',
                'encuesta.informacion as Información_Extra'
                
            )
            ->get()
            ->toArray(); // Convertimos a array

        // Agregamos los encabezados manualmente
        array_unshift($data, [
            'Restaurante',
            'RUC',
            'Razón Social',
            'Nombre del Respondiente',
            'Celular',
            'Información Extra'
        ]);

        // Usamos la instancia correcta de Excel
        return Excel::load($data, function ($excel) {
            $excel->sheet('Datos', function ($sheet) {
                $sheet->fromArray($data);
            });
        })->export('xlsx'); 
        // Descargar el archivo directamente
        // Puedes cambiar 'xlsx' a 'csv' o 'xls'
        
    }
}