<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Administrador;
use App\Models\Restaurantes;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class AdminController extends Controller implements HasMiddleware
{
    
  
    public static function middleware(): array
    {
        return [
            'web',
            new Middleware('log', only: ['index']),
            
        ];
    }
    

public function dashboard()
{
    $this->middleware('web');
    #$restaurantes = Restaurantes::all();
    #return view('admin.dashboard', compact('restaurantes'));
    #dd(auth()->guard('admin')->check(), auth()->guard('admin')->user());
     // Verifica si el usuario está autenticado en el guard 'admin'
     if (!session('logueado', false)) { // ✅ Si no está logueado, lo mandamos al login
        #return redirect()->route('admin.login')->withErrors(['error' => 'Debes iniciar sesión']);
        return view('admin.login');
    }
    $restaurantes = Restaurantes::all();
    return view('admin.dashboard', compact('restaurantes'));

    // Si no está autenticado, devuelve la vista de login
    #return view('admin.login');
}
public function logout()
{
    Auth::guard('web')->logout();
    return redirect()->route('login');
}
public function verEncuesta()
{
    $restaurantes = Restaurantes::all();
    return view('admin.verencuesta', compact('restaurantes'));
}




   
}
