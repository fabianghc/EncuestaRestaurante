<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\Restaurantes;

class ImportExcelController extends Controller
{
    public function showImportForm()
    {
        return view('admin.import'); // Vista donde se subirá el archivo
    }

    public function import(Request $request)
    {
        $request->validate([
            'excel_file' => 'required|mimes:xlsx,xls',
        ]);

        $file = $request->file('excel_file');
        $spreadsheet = IOFactory::load($file->getPathname());
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();

        foreach ($rows as $index => $row) {
            if ($index == 0) continue; // Omitir encabezados

            $ruc = $row[0] ?? null;
            $razon_social = $row[1] ?? null;
            $nombre = $row[2] ?? null;
            $codigo_validacion = $row[3] ?? null;

            if (!$codigo_validacion) continue;

            // Verificar si el código de validación ya existe
            $exists = Restaurantes::where('codigo_validacion', $codigo_validacion)->exists();
            
            if (!$exists) {
                Restaurantes::create([
                    'Ruc' => $ruc,
                    'razon_social' => $razon_social,
                    'nombre' => $nombre,
                    'codigo_validacion' => $codigo_validacion,
                    'estado' => 'N', // Estado por defecto
                ]);
            }
        }

        return redirect()->back()->with('success', 'Datos importados correctamente.');
    }
}
