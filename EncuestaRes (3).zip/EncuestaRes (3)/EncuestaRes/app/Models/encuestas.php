<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Models\Restaurantes;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class encuestas extends Model
{
    
    use HasFactory;
    protected $table = 'encuesta';
    protected $fillable = ['nombre', 'numCelular', 'informacion', 'archivo', 'idRestaurante']; 
    public function restaurante()
    {
        return $this->belongsTo(Restaurantes::class);
    }
}

