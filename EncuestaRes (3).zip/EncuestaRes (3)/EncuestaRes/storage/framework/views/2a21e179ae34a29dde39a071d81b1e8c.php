<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>¡Gracias por tu respuesta!</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body {
      background: linear-gradient(90deg, #f8f9fa, #e9ecef);
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }
    .container {
      max-width: 600px;
    }
    .card {
      border: none;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    .card-header {
      background: linear-gradient(90deg, #28a745, #85e085);
      color: #fff;
      font-size: 1.5rem;
      font-weight: bold;
      text-align: center;
      padding: 1rem;
      text-decoration: underline;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    .card-body {
      padding: 2rem;
    }
    h2 {
      color: #007bff;
      text-decoration: underline;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    .btn-primary {
      background: linear-gradient(90deg, #28a745, #85e085);
      border: none;
    }
  </style>
</head>
<body>
  <div class="container text-center mt-5">
    <div class="card shadow-lg">
      <div class="card-header">
        ¡Gracias por tu respuesta!
      </div>
      <div class="card-body">
        <h2 class="mb-4">¡Gracias por ayudarnos a mejorar tu experiencia con Gesrest!</h2>
        <p class="lead">Tu restaurante digital.</p>
        <!--<a href="<?php echo e(route('validacion.form')); ?>" class="btn btn-primary mt-3">Volver al inicio</a>-->
      </div>
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\EncuestaRes\resources\views/restaurante/agradecimiento.blade.php ENDPATH**/ ?>