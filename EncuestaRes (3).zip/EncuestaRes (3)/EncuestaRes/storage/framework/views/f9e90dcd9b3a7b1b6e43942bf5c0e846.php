<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Validación</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body {
      background: #f8f9fa;
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }
    .container {
      max-width: 500px;
    }
    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #343a40;
      text-decoration: underline;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    .card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .card-header {
      background: linear-gradient(90deg, #007bff, #00c6ff);
      color: #fff;
      font-size: 1.25rem;
      font-weight: bold;
      text-align: center;
      padding: 1rem 1.5rem;
      border-bottom: none;
    }
    .card-body {
      padding: 1.5rem;
      background-color: #fff;
    }
    .btn-primary {
      background: linear-gradient(90deg, #007bff, #00c6ff);
      border: none;
    }
    .alert-danger {
      font-size: 1rem;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        Validación
      </div>
      <div class="card-body">
        <h2>Ingrese su código de validación</h2>
        <form action="<?php echo e(route('validacion.validate')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label for="codigo" class="form-label">Código:</label>
            <input type="text" class="form-control" id="codigo" name="codigo" required>
          </div>
          <button type="submit" class="btn btn-primary">Validar</button>
        </form>
        <?php if($errors->any()): ?>
          <div class="alert alert-danger mt-3">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\EncuestaRes\resources\views/restaurante/validacion.blade.php ENDPATH**/ ?>